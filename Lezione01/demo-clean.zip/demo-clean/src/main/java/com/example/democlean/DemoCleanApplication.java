package com.example.democlean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoCleanApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoCleanApplication.class, args);
	}

}
