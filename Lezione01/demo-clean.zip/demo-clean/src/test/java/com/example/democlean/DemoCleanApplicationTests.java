package com.example.democlean;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCleanApplicationTests {

	@Test
	void contextLoads() {
	}

}
